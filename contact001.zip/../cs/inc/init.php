<?php
$GLOBALS['config'] = array(
		"config"=>array("name" => "Social-Media"),
		"mysql" => array(
		"host" => "127.0.0.1", //127.0.0.1.
		"user" => "root", //root
		"password" => "", //password
		"db" => "cs", //social-media
		"port" => "3306", //3306
	),
	"remember" => array(
		"expiry" => 604800,
	),
	"session" => array (
		"token_name" => "token",
		"cookie_name"=>"cookie",
		"session_name"=>"session"
	),
);

session_start();

spl_autoload_register(function($class){
	require 'inc/classes/'.$class.'.class.php';
});

new DB(Config::get('mysql/host'),Config::get('mysql/port'),Config::get('mysql/user'),Config::get('mysql/password'), Config::get('mysql/db'));


require_once 'functions.php';