<?php
class Input{
	public static function get($item) {
		if(isset($_POST[$item])){
			parse_str(file_get_contents('php://input'), $_POST);
			return $_POST[$item];
		}else if(isset($_GET[$item])){
			parse_str(file_get_contents('php://input'), $_GET);
			return $_GET[$item];
		}else if($_SERVER['REQUEST_METHOD'] === 'PUT'){
			parse_str(file_get_contents('php://input'), $_PUT);
			return $_PUT[$item];
		}
	}
	public static function exists($type = 'post'){
		switch ($type){
			case 'post':
				return ($_SERVER['REQUEST_METHOD'] === 'POST') ? true : false;
				break;
			case 'get':
				return ($_SERVER['REQUEST_METHOD'] === 'GET') ? true : false;
				break;
			case 'delete':
				return ($_SERVER['REQUEST_METHOD'] === 'DELETE') ? true:false;
				break;
			case 'put':
				return ($_SERVER['REQUEST_METHOD'] === 'PUT') ? true:false;
				break;
			case 'patch':
				return ($_SERVER['REQUEST_METHOD'] === 'PATCH') ? true:false;
				break;
			default:
				return false;
				break;
		}
	}
}