<?php
class DB{
	private static $_instances = array();
	private $_pdo, $_query, $_error = false, $_results, $_count = 0, $_prefix;
	public function __construct($host, $port, $user, $password, $db, $prefix=""){
		try {
			$this->_pdo = new PDO('mysql:host='.$host.';dbname='.$db,$user,$password);
			$this->_prefix = $prefix;
			self::$_instances[$db] = $this;
		} catch(PDOException $e) {
			die($e->getMessage());
		}
	}

	public static function getInstance($db){
		if(isset(self::$_instances[$db])){
			return self::$_instances[$db];
		}
		return null;
	}

	public function query($sql, $params = array()) {
		$this->_error = false;
		if($this->_query = $this->_pdo->prepare($sql)) {
			$i = 1;
			if(count($params)) {
			   	foreach($params as $param) {
			 		$this->_query->bindValue($i, $param);
			 		$i++;
			 	}
			}	 
			if($this->_query->execute()) {
				$this->_results = $this->_query->fetchAll(PDO::FETCH_OBJ);
				$this->_count = $this->_query->rowCount();
			} else {$this->_error = true;}
		}
		return $this;
	}
	public function action($action, $table, $where = array()) {
		if (count($where) == 3) {
			$operators = array('=','>','<','>=','<=',);
			$field    = $where[0]; 
			$operator = $where[1];
			$value    = $where[2];
			$table = $this->_prefix.$table;
			//check that operator is valid then contstruct the query
			if (in_array($operator, $operators)){
				$sql = "{$action} FROM {$table} WHERE {$field} {$operator} ?";
				//bind data if there is no errors with the query
				if (!$this->query($sql, array($value))->error()) {return $this;}
			}
		}
		return false;
	}
	public function get($table, $where){
		return $this->action('SELECT *', $table, $where);
	}
	public function delete($table, $where){
		return $this->action('DELETE', $table, $where);
	}
	public function insert($table, $fields = array()) {
		$keys = array_keys($fields);
		$values = '';
		$i = 1;
		foreach ($fields as $field) {
			$values .= "?";
			if ($i < count($fields)) {$values .= ", ";}
			$i++;
		}
		$table = $this->_prefix.$table;
		$sql = "INSERT INTO {$table} (`".implode('`, `', $keys)."`) VALUES ({$values}) ";
		if (!$this->query($sql, $fields)->error()) {return true;}
	
		return false;
	}
	public function update($table, $id, $fields) {
		$set = '';
		$i = 1;
		foreach ($fields as $name => $value) {
			$set .= "{$name} = ?";
			if ($i < count($fields)) {$set .= ', ';}
			$i++;
		}
		$table = $this->_prefix . $table;
		$sql = "UPDATE {$table} SET {$set} WHERE id = {$id}";
		if(!$this->query($sql, $fields)->_error) {return true;}
		return false;
	}
	public function createTable($name, $table_data = array(), $other){
		$name = $this->_prefix.$name;
		$table_col = "";
		$i = 1;
		foreach ($table_data as $col => $data) {
			$table_col .= "{$col}";
			foreach ($data as $d) {
				$table_col .= " $d ";
			}
			if($i < count($table_data)){$table_col.=", ";}
			$i++;
		}
		$sql = "CREATE TABLE `{$name}` ({$table_col}) {$other}";
			if(!$this->query($sql)->error()) {
				return $this;
			}
		return false;
	}
	public function results(){
		return $this->_results;
	}
	public function resultJSON(){
		return json_encode($this->_results);
	}
	public function count() {
		return $this->_count;
	}
	public function first() {
		$results = $this->results();
		return $results[0];
	}
	public function error() {
		return $this->_error;
	}
}
?>