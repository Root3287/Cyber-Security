<?php
class Redirect{
	public static function to($location){
		if($location){
			if (is_numeric($location)) {
				http_response_code($location);
				$GLOBALS['json_result']['status'] = $location;
				echo json_encode($GLOBALS['json_result'], JSON_PRETTY_PRINT);
				exit();
			}
			header('Location: '.$location);
			exit();
		}
	}
}