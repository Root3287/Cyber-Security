<?php 
require 'inc/init.php';
$router = new Router();
$router->add("/", function(){
	require 'pages/index.php';
});
$router->add("/contact", function(){
	require "pages/contact.php";
});
$router->add("/admin/contact", function(){
	require "pages/admin/contact.php";
});
$router->run();
?>