<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cyber</title> 
<meta name="author" content="Timothy Gibbons">
<meta name="copyright" content="Copyright (C) Timothy Gibbons 2015;">
<meta name="description" content="">
<meta name="keywords" content="">
<meta charset="UTF-8">
<link rel="stylesheet" href="/assets/css/3.css">
<!-- Latest compiled and minified JavaScript -->
<script src="/assets/js/jquery.js"></script>
<script src="/assets/js/bootstrap.js"></script>