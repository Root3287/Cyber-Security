<?php
$db = DB::getInstance(Config::get('mysql/db'));
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<?php include "assets/head.php";?>
	</head>
	<body>
		<div class="container">
			<h1>Message</h1>
			<div class="table-responsive">
				<table class="table table-striped table-hover">
					<thead>
						<tr>
							<th>ID</th>
							<th>Name</th>
							<th>Email</th>
							<th>Message</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($db->get("comments", ["1", "=", "1"])->results() as $results):?>
						<tr>
							<th><?php echo $results->id;?></th>
							<td><?php echo $results->name;?></td>
							<td><?php echo $results->email;?></td>
							<td><?php echo $results->message;?></td>
						</tr>
						<?php endforeach;?>
					</tbody>
				</table>
			</div>
		</div>
	</body>
</html>