<?php
if(Input::exists()){
	$val = new Validation();
	$validate = $val->check($_POST, [
		"name" => [
			"required" => true,
			"min" => 1,
			"max" => 254,
		],
		"email" => [
			"required" => true,
			"min" => 3,
			"max" => 255,
			"spaces" => false,
		],
		"message" => [
			"required" => true,
			"min" => 2
		],
	]);

	if(!$validate->passed()){
		$message = "";
		foreach($validate->errors() as $error){
			$message = $message.$error;
			$message = $message."<br>";
		}
		Session::flash("action", '<div class="alert alert-danger">'.$message.'</div>');
	}else{
		DB::getInstance(Config::get('mysql/db'))->insert("comments", [
			"name" => Input::get("name"),
			"email" => Input::get("email"),
			"message" => Input::get("message"),
		]);
		Session::flash("action", '<div class="alert alert-success">Your message went through</div>');
	}
}
?>
<html>
	<head>
		<?php include "assets/head.php";?>
	</head>
	<body>
		<div class="container">
			<?php if(Session::exists('action')){echo Session::flash('action');}?>
			<h1>Contact Us</h1>
			<form action="" method="post" autocomplete="off">
				<div class="form-group">
					<label for="name">Name:</label>
					<input type="text" name="name" class="form-control input-md">
				</div>
				<div class="form-group">
					<label for="email" name="email">Email:</label>
					<input type="email" name="email" class="form-control input-md">
				</div>
				<div class="form-group">
					<label for="message">Message:</label>
					<textarea name="message" class="form-control input-md"></textarea>
				</div>
				<div class="pull-right"><div class="form-group"><input class="form-control btn btn-primary"type="submit"></div></div>
			</form>
		</div>
	</body>
</html>